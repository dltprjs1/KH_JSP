package com.shop.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class AdminDAO {
	Connection con = null;
	PreparedStatement st = null;
	ResultSet rs = null;
	String sql = null;
	
	public AdminDAO() {	}
	
	private static AdminDAO instance = null;
	
	public static AdminDAO getinstance() {
		if(instance == null) {
			instance = new AdminDAO();
		}
		return instance;
	}
	
	public void openConn() {
		
		try {
			// 1단계 : JNDI 서버 객체 생성
			Context ctx = new InitialContext();
			
			// 2단계 : lookup() 메서드를 이용하여 매칭되는 커넥셔을 찾는다.
			DataSource ds = (DataSource)ctx.lookup("java:comp/env/jdbc/myoracle");
			
			// 3단계 : DataSource 객체를 이용하여 커넥션을 하나 가져온다.
			con = ds.getConnection();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void closeConn(ResultSet rs, PreparedStatement st, Connection con) {
		try {
			if(rs != null) {
				rs.close();
			}
			if(st != null) {
				st.close();
			}
			if(con != null) {
				con.close();
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	public int adminCheck(String admin_id, String admin_pwd) {
		int result = 0;	//관리자 아이디가 틀린 경우
		openConn();
		try {
			sql = "select * from admin_shop where admin_id = ?";
			st = con.prepareStatement(sql);
			st.setString(1,admin_id);
			rs = st.executeQuery();
			if(rs.next()) {
				// DB상에 관리자 로그인 페이지에서 입력한 ID가 존재하는 경우
				
				if(admin_pwd.equals(rs.getString("admin_pwd"))) {
				// DB상에 관리자 로그인 페이지에서 입력한 비밀번호가 존재하는 경우
					result = 1; 
					
				}else {
				// 비밀번가 틀린 경우(아이디는 일치)
					result = -1;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			closeConn(rs, st, con);
		}
		return result;
	}

	public AdminDTO getAdmin(String admin_id) {
		AdminDTO dto = null;
		openConn();
		try {
			sql = "select * from admin_shop where admin_id = ?";
			st = con.prepareStatement(sql);
			st.setString(1,admin_id);
			rs = st.executeQuery();
			if(rs.next()) {
				dto = new AdminDTO();
				dto.setAdmin_id(rs.getString("admin_id"));
				dto.setAdmin_pwd(rs.getString("admin_pwd"));
				dto.setAdmin_name(rs.getString("admin_name"));
				dto.setAdmin_email(rs.getString("admin_email"));
				dto.setAdmin_date(rs.getString("admin_date"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			closeConn(rs, st, con);
		}
		return dto;
	}
}
