package com.admin.action;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shop.controller.Action;
import com.shop.controller.ActionForward;
import com.shop.model.ProductDAO;

public class AdminProductDeleteAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
		int p_num = Integer.parseInt(request.getParameter("pnum").trim());
		int page = Integer.parseInt(request.getParameter("page").trim());
		
		ProductDAO dao = ProductDAO.getinstance();
		dao.productDelete(p_num);
		
		ActionForward forward = new ActionForward();
		
		forward.setRedirect(true);
		
		forward.setPath("admin_product_list.do?page="+page);
		
		return forward;
	}
}
