package com.user.action;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shop.controller.Action;
import com.shop.controller.ActionForward;
import com.shop.model.ProductDAO;
import com.shop.model.ProductDTO;

public class UserCategoryListAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
		
		String code = request.getParameter("code").trim();
		ProductDAO dao = ProductDAO.getinstance();
		int rowsize = 7;
		int page = 1;
		
		if(request.getParameter("page") != null) {
			page = Integer.parseInt(request.getParameter("page").trim());
		}
		
		int block = 10;
		int startNo = (page * rowsize) - (rowsize - 1);
		int lastNo = (page * rowsize);
		int startBlock = (((page-1)/block)*block)+1;
		int lastBlock = (((page-1)/block)*block)+block;
		int totalRecord = dao.productrecord();
		int allPage = (int)Math.ceil(totalRecord/(double)rowsize);
		
		if(lastBlock > allPage) {
			lastBlock = allPage;
		}
		System.out.println(page);
		List<ProductDTO> list = dao.productList(startNo,lastNo,code);
		request.setAttribute("list",list);
		request.setAttribute("rowsize",rowsize);
		request.setAttribute("page",page);
		request.setAttribute("block",block);
		request.setAttribute("startNo",startNo);
		request.setAttribute("lastNo",lastNo);
		request.setAttribute("startBlock",startBlock);
		request.setAttribute("lastBlock",lastBlock);
		request.setAttribute("totalRecord",totalRecord);
		request.setAttribute("allPage",allPage);
		
		ActionForward forward = new ActionForward();
		forward.setRedirect(false);
		forward.setPath("user/user_main.jsp");
		
		
		
		return forward;
	}

}
