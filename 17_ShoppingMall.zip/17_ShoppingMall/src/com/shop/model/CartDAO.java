package com.shop.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class CartDAO {
	Connection con = null;
	PreparedStatement st = null;
	ResultSet rs = null;
	String sql = null;
	
	public CartDAO() {	}
	
	private static CartDAO instance = null;
	
	public static CartDAO getinstance() {
		if(instance == null) {
			instance = new CartDAO();
		}
		return instance;
	}
	
	public void openConn() {
		
		try {
			// 1단계 : JNDI 서버 객체 생성
			Context ctx = new InitialContext();
			
			// 2단계 : lookup() 메서드를 이용하여 매칭되는 커넥셔을 찾는다.
			DataSource ds = (DataSource)ctx.lookup("java:comp/env/jdbc/myoracle");
			
			// 3단계 : DataSource 객체를 이용하여 커넥션을 하나 가져온다.
			con = ds.getConnection();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void closeConn(ResultSet rs, PreparedStatement st, Connection con) {
		try {
			if(rs != null) {
				rs.close();
			}
			if(st != null) {
				st.close();
			}
			if(con != null) {
				con.close();
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	public int insertCart(CartDTO dto) {
		openConn();
		int result = 0 , count=0;
		try {
			sql = "select max(cart_num) from shop_cart";
			st = con.prepareStatement(sql);
			rs = st.executeQuery();
			if(rs.next()) {
				count = rs.getInt(1) + 1;
			}
			sql = "insert into shop_cart values(?,?,?,?,?,?,?,?)";
			st = con.prepareStatement(sql);
			st.setInt(1,count);
			st.setInt(2,dto.getCart_pnum());
			st.setString(3,dto.getCart_userid());
			st.setString(4,dto.getCart_pname());
			st.setInt(5,dto.getCart_pqty());
			st.setInt(6,dto.getCart_price());
			st.setString(7,dto.getCart_pspec());
			st.setString(8,dto.getCart_pimage());
			result = st.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			closeConn(rs, st, con);
		}
		return result;
	}

	public List<CartDTO> getCartList(String userId) {
		List<CartDTO> list = new ArrayList<CartDTO>();
		openConn();
		try {
			sql = "select * from shop_cart where cart_userid = ? order by cart_num desc";
			st = con.prepareStatement(sql);
			st.setString(1,userId);
			rs = st.executeQuery();
			while(rs.next()) {
				CartDTO dto = new CartDTO();
				dto.setCart_num(rs.getInt("cart_num"));
				dto.setCart_pnum(rs.getInt("cart_pnum"));
				dto.setCart_userid(rs.getString("cart_userid"));
				dto.setCart_pname(rs.getString("cart_pname"));
				dto.setCart_pqty(rs.getInt("cart_pqty"));
				dto.setCart_price(rs.getInt("cart_price"));
				dto.setCart_pspec(rs.getString("cart_pspec"));
				dto.setCart_pimage(rs.getString("cart_pimage"));
				list.add(dto);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			closeConn(rs, st, con);
		}
		return list;
	}

	public int deleteCard(int num) {
		int result = 0;
		openConn();
		try {
			sql = "delete from shop_cart where cart_num = ?";
			st = con.prepareStatement(sql);
			st.setInt(1,num);
			result = st.executeUpdate();
			sql = "update shop_cart set cart_num = cart_num - 1 where cart_num > ?";
			st = con.prepareStatement(sql);
			st.setInt(1,num);
			st.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			closeConn(rs, st, con);
		}
		return result;
	}	
}
