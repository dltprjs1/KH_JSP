package com.shop.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class ProductDAO {
	Connection con = null;
	PreparedStatement st = null;
	ResultSet rs = null;
	String sql = null;
	
	public ProductDAO() {	}
	
	private static ProductDAO instance = null;
	
	public static ProductDAO getinstance() {
		if(instance == null) {
			instance = new ProductDAO();
		}
		return instance;
	}
	
	public void openConn() {
		
		try {
			// 1단계 : JNDI 서버 객체 생성
			Context ctx = new InitialContext();
			
			// 2단계 : lookup() 메서드를 이용하여 매칭되는 커넥셔을 찾는다.
			DataSource ds = (DataSource)ctx.lookup("java:comp/env/jdbc/myoracle");
			
			// 3단계 : DataSource 객체를 이용하여 커넥션을 하나 가져온다.
			con = ds.getConnection();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void closeConn(ResultSet rs, PreparedStatement st, Connection con) {
		try {
			if(rs != null) {
				rs.close();
			}
			if(st != null) {
				st.close();
			}
			if(con != null) {
				con.close();
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	public int insertProduct(ProductDTO dto) {
		int result = 0, count = 0;
		openConn();
		try {
			sql = "select max(pnum) from shop_products";
			st = con.prepareStatement(sql);
			rs = st.executeQuery();
			if(rs.next()) {
				count = rs.getInt(1)+1;
			}
			sql = "insert into shop_products values(?,?,?,?,?,?,?,?,?,?,sysdate)";
			st = con.prepareStatement(sql);
			st.setInt(1,count);
			st.setString(2,dto.getPname());
			st.setString(3,dto.getPcategory_fk());
			st.setString(4,dto.getPcompany());
			st.setString(5,dto.getPimage());
			st.setInt(6,dto.getPqty());
			st.setInt(7,dto.getPrice());
			st.setString(8,dto.getPspec());
			st.setString(9,dto.getPcontents());
			st.setInt(10, dto.getPoint());
			result = st.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			closeConn(rs, st, con);
		}
		return result;
	}

	public int productrecord() {
		int result = 0;
		openConn();
		try {
			sql = "select count(*) from shop_products";
			st = con.prepareStatement(sql);
			rs = st.executeQuery();
			if(rs.next()) {
				result = rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			closeConn(rs, st, con);
		}
		return result;
	}

	public List<ProductDTO> productList(int startNo, int lastNo) {
		List<ProductDTO> list = new ArrayList<ProductDTO>();
		openConn();
		try {
			sql = "select * from (select rownum as rnum , a.* from(select * from shop_products order by pnum desc)a where rownum <= ? )where rnum >= ?";
			st = con.prepareStatement(sql);
			st.setInt(1,lastNo);
			st.setInt(2,startNo);
			rs = st.executeQuery();
			while(rs.next()) {
				ProductDTO dto = new ProductDTO();
				dto.setPnum(rs.getInt("pnum"));
				dto.setPname(rs.getString("pname"));
				dto.setPcategory_fk(rs.getString("pcategory_fk"));
				dto.setPcompany(rs.getString("pcompany"));
				dto.setPimage(rs.getString("pimage"));
				dto.setPqty(rs.getInt("pqty"));
				dto.setPrice(rs.getInt("price"));
				dto.setPspec(rs.getString("pspec"));
				dto.setPcontents(rs.getString("pcontents"));
				dto.setPoint(rs.getInt("point"));
				dto.setPinputdate(rs.getString("pinputdate"));
				list.add(dto);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			closeConn(rs, st, con);
		}
		return list;
	}

	public ProductDTO productContent(int pnum) {
		ProductDTO dto = null;
		openConn();
		try {
			sql = "select * from shop_products where pnum = ?";
			st = con.prepareStatement(sql);
			st.setInt(1,pnum);
			rs = st.executeQuery();
			if(rs.next()) {
				dto = new ProductDTO();
				dto.setPnum(rs.getInt("pnum"));
				dto.setPname(rs.getString("pname"));
				dto.setPcategory_fk(rs.getString("pcategory_fk"));
				dto.setPcompany(rs.getString("pcompany"));
				dto.setPimage(rs.getString("pimage"));
				dto.setPqty(rs.getInt("pqty"));
				dto.setPrice(rs.getInt("price"));
				dto.setPspec(rs.getString("pspec"));
				dto.setPcontents(rs.getString("pcontents"));
				dto.setPoint(rs.getInt("point"));
				dto.setPinputdate(rs.getString("pinputdate"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			closeConn(rs, st, con);
		}
		return dto;
	}

	public int updateProduct(ProductDTO dto) {
		int result = 0;
		openConn();
		try {
			sql = "update shop_products set pimage=?, pqty=? , price=? , pspec=?, pcontents=?, point=? where pnum=?";
			st = con.prepareStatement(sql);
			st.setString(1,dto.getPimage());
			st.setInt(2,dto.getPqty());
			st.setInt(3,dto.getPrice());
			st.setString(4,dto.getPspec());
			st.setString(5,dto.getPcontents());
			st.setInt(6,dto.getPoint());
			st.setInt(7,dto.getPnum());
			result = st.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			closeConn(rs, st, con);
		}
		return result;
	}

	public void productDelete(int p_num) {
		openConn();
		try {
			sql = "delete from shop_products where pnum=?";
			st = con.prepareStatement(sql);
			st.setInt(1,p_num);
			st.executeUpdate();
			
			sql="update shop_products set pnum=pnum+1 where pnum > ?";
			st = con.prepareStatement(sql);
			st.setInt(1,p_num);
			st.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			closeConn(rs, st, con);
		}
	}
	public List<ProductDTO> productList(int startNo, int lastNo , String code) {
		List<ProductDTO> list = new ArrayList<ProductDTO>();
		openConn();
		try {
			sql = "select * from (select rownum as rnum , a.* from(select * from shop_products where pcategory_fk = ? order by pnum desc)a where rownum <= ? )where rnum >= ?";
			st = con.prepareStatement(sql);
			st.setString(1,code);
			st.setInt(2,lastNo);
			st.setInt(3,startNo);
			rs = st.executeQuery();
			while(rs.next()) {
				ProductDTO dto = new ProductDTO();
				dto.setPnum(rs.getInt("pnum"));
				dto.setPname(rs.getString("pname"));
				dto.setPcategory_fk(rs.getString("pcategory_fk"));
				dto.setPcompany(rs.getString("pcompany"));
				dto.setPimage(rs.getString("pimage"));
				dto.setPqty(rs.getInt("pqty"));
				dto.setPrice(rs.getInt("price"));
				dto.setPspec(rs.getString("pspec"));
				dto.setPcontents(rs.getString("pcontents"));
				dto.setPoint(rs.getInt("point"));
				dto.setPinputdate(rs.getString("pinputdate"));
				list.add(dto);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			closeConn(rs, st, con);
		}
		return list;
	}
}
