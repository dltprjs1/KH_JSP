package com.admin.action;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shop.controller.Action;
import com.shop.controller.ActionForward;
import com.shop.model.ProductDAO;
import com.shop.model.ProductDTO;

public class AdminProductModifyAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// get방식으로 넘어온 제품 번호에 해당하는 제품의 상세내역을 DB에서 조회하여 수점 폼 페이지로 이동
		
		int pnum = Integer.parseInt(request.getParameter("pnum").trim());
		int page = Integer.parseInt(request.getParameter("page").trim());
		
		ProductDAO dao = ProductDAO .getinstance();
		
		ProductDTO content = dao.productContent(pnum);
		request.setAttribute("content",content);
		request.setAttribute("page",page);
		ActionForward forward = new ActionForward();
		forward.setRedirect(false);
		forward.setPath("admin/admin_product_modify.jsp");
		
		return forward;
	}

}
