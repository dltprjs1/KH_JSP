package com.shop.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class UserDAO {
	Connection con = null;
	PreparedStatement st = null;
	ResultSet rs = null;
	String sql = null;
	
	public UserDAO() {	}
	
	private static UserDAO instance = null;
	
	public static UserDAO getinstance() {
		if(instance == null) {
			instance = new UserDAO();
		}
		return instance;
	}
	
	public void openConn() {
		
		try {
			// 1단계 : JNDI 서버 객체 생성
			Context ctx = new InitialContext();
			
			// 2단계 : lookup() 메서드를 이용하여 매칭되는 커넥셔을 찾는다.
			DataSource ds = (DataSource)ctx.lookup("java:comp/env/jdbc/myoracle");
			
			// 3단계 : DataSource 객체를 이용하여 커넥션을 하나 가져온다.
			con = ds.getConnection();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void closeConn(ResultSet rs, PreparedStatement st, Connection con) {
		try {
			if(rs != null) {
				rs.close();
			}
			if(st != null) {
				st.close();
			}
			if(con != null) {
				con.close();
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	public int userCheck(String user_id, String user_pwd) {
		int result = 0;
		openConn();
		try {
			sql = "select * from member10 where memid = ?";
			st = con.prepareStatement(sql);
			st.setString(1,user_id);
			rs = st.executeQuery();
			if(rs.next()) {
				if(user_pwd.equals(rs.getString("pwd"))) {
					result = 1;
				}else {
					result = -1;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			closeConn(rs, st, con);
		}
		return result;
	}

	public UserDTO getMember(String user_id) {
		UserDTO dto = null;
		openConn();
		try {
			sql="select * from member10 where memid=?";
			st = con.prepareStatement(sql);
			st.setString(1,user_id);
			rs = st.executeQuery();
			if(rs.next()) {
				dto = new UserDTO();
				dto.setNum(rs.getInt("num"));
				dto.setMemid(rs.getString("memid"));
				dto.setMemname(rs.getString("memname"));
				dto.setPwd(rs.getString("pwd"));
				dto.setAge(rs.getInt("age"));
				dto.setMileage(rs.getInt("mileage"));
				dto.setRegdate(rs.getString("regdate"));
				dto.setAddr(rs.getString("addr"));
				dto.setJob(rs.getString("job"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			closeConn(rs, st, con);
		}
		return dto;
	}
}
