package com.admin.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import com.shop.controller.Action;
import com.shop.controller.ActionForward;
import com.shop.model.ProductDAO;
import com.shop.model.ProductDTO;

public class AdminProductUpdateAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String filedirectory = "C:\\NCS\\workspace(jsp)\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp0\\wtpwebapps\\17_ShoppingMall\\upload";
		int filesize = 10*1024*1024;
		MultipartRequest mr = new MultipartRequest(request, filedirectory, filesize, "UTF-8", new DefaultFileRenamePolicy());
		
		int p_num = Integer.parseInt(mr.getParameter("p_num").trim());
		String p_name = mr.getParameter("p_name").trim();
		String p_category = mr.getParameter("p_category").trim();
		String p_company = mr.getParameter("p_company").trim();
		int p_qty = Integer.parseInt(mr.getParameter("p_qty").trim());
		int p_price = Integer.parseInt(mr.getParameter("p_price").trim());
		String p_spec = mr.getParameter("p_spec").trim();
		String p_content = mr.getParameter("p_content").trim();
		int p_point = Integer.parseInt(mr.getParameter("p_point").trim());
		int page = Integer.parseInt(mr.getParameter("page").trim());
		// getFilesystemName() : 업로드될 파일의 이름을 문자열로 반환해 주는 메서드
		String p_image = mr.getFilesystemName("p_image_new");
		
		if(p_image == null) {
			p_image = mr.getParameter("p_image_old").trim();
		}
		
		ProductDTO dto = new ProductDTO();
		dto.setPnum(p_num);
		dto.setPname(p_name);
		dto.setPcompany(p_company);
		dto.setPcategory_fk(p_category);
		dto.setPcontents(p_company);
		dto.setPqty(p_qty);
		dto.setPrice(p_price);
		dto.setPspec(p_spec);
		dto.setPcontents(p_content);
		dto.setPoint(p_point);
		dto.setPimage(p_image);
		
		ProductDAO dao = ProductDAO.getinstance();
		int res = dao.updateProduct(dto);
		
		ActionForward forward = new ActionForward();
		PrintWriter out = response.getWriter();
		
		if(res > 0) {
			forward.setRedirect(true);
			forward.setPath("admin_product_list.do?page="+page);
		}else {
			out.println("<script>");
			out.println("alert('수정 실패')");
			out.println("history.back()");
			out.println("</script>");
		}
		return forward;
	}
}
